package com.siya.ai.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Siya ka floating hologram (default assistant / power button se aane par dusre app ke upar dikhta hai).
 * State ke hisaab se rang aur effect badalte hain: sun rahi (green ripple), soch rahi (amber orbit),
 * bol rahi (pink bars). Neeche live caption: user ne kya bola aur Siya kya keh rahi hai.
 */
class OrbOverlayView(context: Context, private val onTap: () -> Unit) : View(context) {
    private val d = resources.displayMetrics.density
    private val w = 300 * d
    private val h = 168 * d

    private val card = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.4f * d }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 15f * d; isFakeBoldText = true }
    private val chip = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9.5f * d; isFakeBoldText = true; letterSpacing = 0.12f }
    private val capUser = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAB8E8FF.toInt(); textSize = 11.5f * d }
    private val capSiya = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 13f * d }
    private val rect = RectF()
    private val path = Path()

    private var t = 0f
    private var level = 0.1f
    private var shown = 0.1f
    private var stateName = "waiting"
    private var label = "Siya"
    private var userCap = ""
    private var siyaCap = ""

    // (glow, body, deep)
    private fun pal(): Triple<Int, Int, Int> = when (stateName) {
        "listening" -> Triple(0xFF7CFFD8.toInt(), 0xFF00C98D.toInt(), 0xFF22D3EE.toInt())
        "processing", "thinking", "waiting" -> Triple(0xFFFFD27A.toInt(), 0xFFFF9F1C.toInt(), 0xFFB07CFF.toInt())
        "speaking" -> Triple(0xFFFF9BEA.toInt(), 0xFFD946EF.toInt(), 0xFF8B5CF6.toInt())
        else -> Triple(0xFF8FB3D9.toInt(), 0xFF3D6A99.toInt(), 0xFF5B5F97.toInt())
    }

    private val anim = ValueAnimator.ofFloat(0f, 16f).apply {
        duration = 16000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; shown += (level - shown) * 0.25f; invalidate() }
    }

    fun update(event: Map<String, Any?>) {
        when (event["type"]) {
            "state" -> {
                stateName = event["state"] as? String ?: "idle"
                label = when (stateName) {
                    "listening" -> "Siya sun rahi hai"
                    "speaking" -> "Siya bol rahi hai"
                    "processing", "thinking" -> "Siya soch rahi hai"
                    "waiting" -> "Siya jud rahi hai..."
                    else -> "Siya"
                }
                invalidate()
            }
            "amp" -> level = ((event["v"] as? Double) ?: 0.0).toFloat().coerceIn(0f, 1f)
            "caption" -> {
                val who = event["who"] as? String
                val text = (event["text"] as? String).orEmpty()
                if (who == "user") { userCap = text; siyaCap = "" } else siyaCap = text
                invalidate()
            }
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onMeasure(wSpec: Int, hSpec: Int) = setMeasuredDimension(w.toInt(), h.toInt())

    private fun wrap(text: String, p: TextPaint, width: Int, maxLines: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setMaxLines(maxLines).setEllipsize(android.text.TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

    override fun onDraw(c: Canvas) {
        val (a, b, deep) = pal()
        val e = if (stateName == "idle") 0.25f else 1f

        // glass card
        rect.set(2 * d, 2 * d, width - 2 * d, height - 2 * d)
        card.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), intArrayOf(0xF0071626.toInt(), 0xF2030A14.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, 28 * d, 28 * d, card)
        border.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), intArrayOf((a and 0x00FFFFFF) or 0xCC000000.toInt(), (deep and 0x00FFFFFF) or 0x55000000), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, 28 * d, 28 * d, border)

        // ── hologram (left) ──
        val cx = 62 * d
        val cy = 66 * d
        val breathe = 0.5f + 0.5f * sin(t * 2 * PI.toFloat() * (0.06f + 0.05f * e))
        val r = (21f + 3f * breathe + 9f * shown * e) * d

        glow.shader = RadialGradient(cx, cy, r * 3.1f, intArrayOf((a and 0x00FFFFFF) or ((60 + 80 * e).toInt() shl 24), (deep and 0x00FFFFFF) or 0x22000000, 0x00000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 3.1f, glow)

        // projector base
        val baseY = cy + r * 1.75f
        line.strokeWidth = 1.1f * d
        for (i in 0 until 3) {
            val bw = r * (2.5f - i * 0.55f)
            rect.set(cx - bw / 2, baseY - bw * 0.13f + i * r * 0.05f, cx + bw / 2, baseY + bw * 0.13f + i * r * 0.05f)
            line.color = (a and 0x00FFFFFF) or ((((0.55f - i * 0.14f) * (0.4f + 0.6f * e)) * 255).toInt() shl 24)
            c.drawOval(rect, line)
        }
        path.reset(); path.moveTo(cx - r * 1.0f, baseY); path.lineTo(cx - r * 0.65f, cy + r * 0.45f); path.lineTo(cx + r * 0.65f, cy + r * 0.45f); path.lineTo(cx + r * 1.0f, baseY); path.close()
        fill.shader = LinearGradient(0f, baseY, 0f, cy + r * 0.45f, (a and 0x00FFFFFF) or 0x38000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawPath(path, fill)

        // dashed ring
        line.strokeWidth = 1.4f * d
        line.color = (deep and 0x00FFFFFF) or ((80 + 120 * e).toInt() shl 24)
        val dr = r * 1.95f
        val rot = t * (14f + 40f * e)
        rect.set(cx - dr, cy - dr, cx + dr, cy + dr)
        for (i in 0 until 30) c.drawArc(rect, rot + i * 12f, 6.5f, false, line)

        when (stateName) {
            "listening" -> for (i in 0 until 3) {                      // ripple rings
                val ph = (t * 0.8f + i / 3f) % 1f
                line.strokeWidth = (2f * (1 - ph) + 0.4f) * d
                line.color = (a and 0x00FFFFFF) or (((1 - ph) * 0.7f * 255).toInt() shl 24)
                c.drawCircle(cx, cy, r * (1.15f + ph * 1.4f), line)
            }
            "processing", "thinking", "waiting" -> for (i in 0 until 3) {   // orbit arcs
                val rad = r * (1.45f + i * 0.22f)
                val dir = if (i % 2 == 0) 1f else -1f
                line.strokeWidth = (2.6f - i * 0.5f) * d
                line.color = ((if (i == 1) deep else a) and 0x00FFFFFF) or 0xE6000000.toInt()
                rect.set(cx - rad, cy - rad, cx + rad, cy + rad)
                c.drawArc(rect, dir * t * (110f + i * 60f) + i * 110f, 90f + 30f * i, false, line)
            }
            "speaking" -> {                                            // radial bars
                line.strokeWidth = 2.2f * d
                line.color = (a and 0x00FFFFFF) or 0xE6000000.toInt()
                for (i in 0 until 40) {
                    val ang = i * 2 * PI.toFloat() / 40
                    val wob = (sin(i * 0.9f + t * 9f) * 0.5f + 0.5f) * abs(sin(i * 0.37f - t * 5f))
                    val len = r * (0.08f + (0.10f + 0.55f * shown) * wob)
                    c.drawLine(cx + cos(ang) * r * 1.3f, cy + sin(ang) * r * 1.3f, cx + cos(ang) * (r * 1.3f + len), cy + sin(ang) * (r * 1.3f + len), line)
                }
            }
        }

        // core orb + scanlines
        orb.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.45f, r * 1.9f, intArrayOf(a, b, (deep and 0x00FFFFFF) or 0xFF000000.toInt()), floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, orb)
        c.save()
        path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(path)
        line.strokeWidth = 1f; line.color = 0x14FFFFFF
        var yy = cy - r
        while (yy < cy + r) { c.drawLine(cx - r, yy, cx + r, yy, line); yy += 4 * d }
        val sy = cy - r + ((t * (0.35f + 0.5f * e)) % 1f) * r * 2
        fill.shader = LinearGradient(0f, sy - r * 0.12f, 0f, sy + r * 0.12f, intArrayOf(0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(cx - r, sy - r * 0.12f, cx + r, sy + r * 0.12f, fill)
        c.restore()

        // mic glyph
        line.shader = null
        line.strokeWidth = max(1.4f, r * 0.12f); line.color = 0xE6FFFFFF.toInt()
        c.drawLine(cx, cy - r * 0.46f, cx, cy + r * 0.16f, line)
        rect.set(cx - r * 0.59f, cy - r * 0.76f, cx + r * 0.59f, cy + r * 0.69f)
        c.drawArc(rect, 0f, 180f, false, line)
        c.drawLine(cx, cy + r * 0.20f, cx, cy + r * 0.47f, line)
        c.drawLine(cx - r * 0.28f, cy + r * 0.47f, cx + r * 0.28f, cy + r * 0.47f, line)

        // ── text (right) ──
        val tx = 122 * d
        c.drawText(label, tx, 34 * d, title)
        chip.color = (a and 0x00FFFFFF) or 0xFF000000.toInt()
        c.drawText(when (stateName) { "listening" -> "LISTENING"; "speaking" -> "SPEAKING"; "idle" -> "STANDBY"; else -> "THINKING" }, tx, 50 * d, chip)

        val tw = (w - tx - 16 * d).toInt()
        var ty = 62 * d
        if (userCap.isNotBlank()) {
            val l = wrap(userCap, capUser, tw, 2)
            c.save(); c.translate(tx, ty); l.draw(c); c.restore(); ty += l.height + 4 * d
        }
        if (siyaCap.isNotBlank()) {
            val l = wrap(siyaCap, capSiya, tw, 3)
            c.save(); c.translate(tx, ty); l.draw(c); c.restore()
        } else if (userCap.isBlank()) {
            c.drawText("Bolo, main sun rahi hoon", tx, ty + 12 * d, capUser)
        }

        // close hint
        capUser.textSize = 9f * d
        c.drawText("tap = band", w - 66 * d, h - 14 * d, capUser)
        capUser.textSize = 11.5f * d
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) { onTap(); performClick() }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
